import requests
import time


class LiuGuan:
    def __init__(self):
        self.req = requests.session()
        self.last_request_times = 0

    def get_one_from_flow(self):
        url = 'ger_ip_url'
        res = self.req.get(url=url)
        ip = res.text.replace('\n', '')
        ip_proxies = {
            'https': 'http://' + ip,
            'http': 'http://' + ip
        }
        return ip_proxies

    def get_list_from_flow(self):
        if self.last_request_times != 0 and (time.time()-self.last_request_times) < 10:
            time.sleep(10 - (time.time()-self.last_request_times))
        self.last_request_times = time.time()
        url = 'ger_ip_url'
        res = self.req.get(url=url)
        ips = res.text.strip('\n').strip().split('\n')
        ip_proxies_list = [{'https': 'http://' + ip, 'http': 'http://' + ip} for ip in ips]
        return ip_proxies_list

    def test_ip_proxy(self):
        url = 'http://icanhazip.com/'
        res = self.req.get(url=url)
        print(res.text)


if __name__ == "__main__":
    p = LiuGuan()
