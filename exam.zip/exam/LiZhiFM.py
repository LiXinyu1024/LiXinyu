import requests
import time
import threading
import random
import os
import pandas as pd
from lxml import etree
from ProxySupport import LiuGuan
true = True
false = False
none = None
null = None


class LiZhiFM(threading.Thread):
    def __init__(self, page, lg):
        super(LiZhiFM, self).__init__()
        self.req = requests.session()
        self.lg = lg
        self.page = page
        self.error_item = []
        self.result = {}

    # 下载歌手的头像
    def down_image(self, image_url_list, names):
        headers = {
            'User-agent': 'Mozilla/5.0 (iPhone; CPU iPhone OS 13_2_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.0.3 Mobile/15E148 Safari/604.1'
        }
        image_path = []
        if not os.path.exists('./image/'):
            os.makedirs('./image/')
        for i, image_url in enumerate(image_url_list):
            res = self.req.get(url=image_url, headers=headers)
            image = res.content
            # 去除特殊字符
            file_path = './image/{}.jpg'.format(names[i].replace('/', '_').replace('*', '').replace('|', '').replace('\\', '').replace('\'', ''))
            image_path.append(file_path)
            with open(file_path, 'wb') as f:
                f.write(image)
            time.sleep(random.random())
        return image_path

    # 获取一级界面的所有歌手信息
    def parse_first_page(self, page, label='24229798160629936'):
        url = 'https://www.lizhi.fm/label/{}/{}.html'.format(label, page)
        headers = {
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
            'Accept-Encoding': 'gzip, deflate, br',
            'Accept-Language': 'zh-CN,zh;q=0.9',
            'Cache-Control': 'max-age=0',
            'Connection': 'keep-alive',
            'Cookie': 'Hm_lvt_45dcc777b283462d0db81563b6c09dbe=1687406500; Hm_lpvt_45dcc777b283462d0db81563b6c09dbe=1687406560',
            'Host': 'www.lizhi.fm',
            'Sec-Ch-Ua': '"Not.A/Brand";v="8", "Chromium";v="114", "Google Chrome";v="114"',
            'Sec-Ch-Ua-Mobile': '?0',
            'Sec-Ch-Ua-Platform': '"Windows"',
            'Sec-Fetch-Dest': 'document',
            'Sec-Fetch-Mode': 'navigate',
            'Sec-Fetch-Site': 'none',
            'Sec-Fetch-User': '?1',
            'Upgrade-Insecure-Requests': '1',
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36'
            }
        page = self.req.get(url=url, headers=headers)
        # 利用xpath解析一级页面中歌手的头像、名称、和对应二级页面的url
        tree = etree.HTML(page.text.strip())
        all_radio_list = tree.xpath('/html/body/div/div[2]/div[1]/div/ul')[0]
        images = all_radio_list.xpath('./li[@class="radio_list"]/a/img/@data-echo')
        platform_code = all_radio_list.xpath('./li/a/span/i/text()')
        platform_code = [('FM ' + x) for x in platform_code]
        names = all_radio_list.xpath('./li[@class="radio_list"]/p[1]/a/text()')
        names = [x.strip('\n').strip() for x in names]
        images = self.down_image(images, names)
        second_page_urls = all_radio_list.xpath('./li[@class="radio_list"]/p[1]/a/@href')
        # 校对不同标签的数据量
        if not (len(images) == len(names) == len(second_page_urls) == len(platform_code)):
            print('解析错误,数据项不吻合...:{},{},{}'.format(len(images), len(names), len(second_page_urls)))
            print(images)
            print(names)
            print(second_page_urls)
            print(platform_code)
            return []
        all_radio_list_info = {'name': names, 'image': images, 'platform_code': platform_code, 'second_page_urls': second_page_urls}
        return all_radio_list_info

    # 获取二级页面中歌手的详细信息
    def parse_second_page(self, second_page_url, singer_index):
        # 获取歌手的歌曲数量、播放量、粉丝数
        url = 'https:' + second_page_url
        headers = {
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
            'Accept-Encoding': 'gzip, deflate, br',
            'Accept-Language': 'zh-CN,zh;q=0.9',
            'Cache-Control': 'max-age=0',
            'Connection': 'keep-alive',
            'Cookie': 'Hm_lvt_45dcc777b283462d0db81563b6c09dbe=1687406500; Hm_lpvt_45dcc777b283462d0db81563b6c09dbe=1687406560',
            'Host': 'www.lizhi.fm',
            'Sec-Ch-Ua': '"Not.A/Brand";v="8", "Chromium";v="114", "Google Chrome";v="114"',
            'Sec-Ch-Ua-Mobile': '?0',
            'Sec-Ch-Ua-Platform': '"Windows"',
            'Sec-Fetch-Dest': 'document',
            'Sec-Fetch-Mode': 'navigate',
            'Sec-Fetch-Site': 'none',
            'Sec-Fetch-User': '?1',
            'Upgrade-Insecure-Requests': '1',
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36'
            }
        page = self.req.get(url=url, headers=headers)
        if page.status_code == 404: # 有的歌手被官方屏蔽了
            page_info = {'radio_cnt': '404 not found', 'signature': '404 not found',
                         'total_songs': pd.DataFrame()}
            return page_info
        tree = etree.HTML(page.text.strip())
        radio_cnt = tree.xpath('/html/body/div[1]/div[2]/div[3]/div[2]/div[1]/p[@class="radioCnt"]/span/text()')
        radio_cnts = 'songs number:{} playback volume:{} fans number:{}'.format(radio_cnt[0], radio_cnt[1], radio_cnt[2])
        signature = tree.xpath('/html/body/div/div[2]/div[3]/div[2]/div[2]/text()')[0]
        # 获取歌手的所有歌曲的信息
        if int(radio_cnt[0]) == 0: # 有的歌手没有歌
            total_songs = pd.DataFrame()
        else:
            total_songs = self.get_songs_info(second_page_url, int(radio_cnt[0]), singer_index)
        page_info = {'radio_cnt': radio_cnts, 'signature': signature,
                     'total_songs': total_songs}
        return page_info

    # 获取歌手所有歌曲信息
    def get_songs_info(self, second_page_url, songs_num, singer_index):
        total_pages = int((songs_num-1) / 10) + 1
        total_songs = []
        ip_list = self.lg.get_list_from_flow()
        ips_num = len(ip_list)
        for page in range(1, total_pages+1):
            print('---获取第{}页歌手第{}页歌曲---'.format(self.page, page))
            self.req.proxies = ip_list[page % ips_num]
            one_page_songs = self.parse_songs_info(second_page_url, page)
            # 保存获取失败的歌曲页面
            if one_page_songs is []:
                self.error_item.append([self.page, singer_index, page, second_page_url])
            total_songs.extend(one_page_songs)
            time.sleep(1 + 1*random.random())
        if total_songs is []:
            return pd.DataFrame()
        total_songs = pd.DataFrame(total_songs)
        return total_songs

    # 下载歌曲
    def download_song(self, publish_dates, song_codes, radio_names, not_download=True, shutdown_num=1):
        # sd是一般流畅 hd是高品质
        headers = {
            'User-agent': 'Mozilla/5.0 (iPhone; CPU iPhone OS 13_2_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.0.3 Mobile/15E148 Safari/604.1'
        }
        if not os.path.exists('./radio/'):
            os.makedirs('./radio/')
        radio_path = []
        for i in range(len(publish_dates)):
            url = 'http://cdn101.gzlzfm.com/audio/{}/{}_sd.m4a'.format(publish_dates[i].replace('-', '/'),
                                                                        song_codes[i])
            # 只下载第一页的歌手的第一首歌
            if i >= shutdown_num or not_download or self.page > 1:
                radio_path.append(url)
                continue
            res = self.req.get(url=url, headers=headers)
            radio = res.content
            # 去除特殊字符
            file_path = './radio/{}.m4a'.format(radio_names[i].replace('/', '_').replace('*', '').replace('|', '').replace('\\', '').replace('\'', ''))
            radio_path.append(file_path)
            with open(file_path, 'wb') as f:
                f.write(radio)
            time.sleep(random.random())
        return radio_path

    # 获取歌手一页歌曲的信息
    def parse_songs_info(self, second_page_url, page):
        url = 'https:' + second_page_url + '/p/{}.html'.format(page)
        headers = {
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
            'Accept-Encoding': 'gzip, deflate, br',
            'Accept-Language': 'zh-CN,zh;q=0.9',
            'Cache-Control': 'max-age=0',
            'Connection': 'keep-alive',
            'Cookie': 'Hm_lvt_45dcc777b283462d0db81563b6c09dbe=1687406500; Hm_lpvt_45dcc777b283462d0db81563b6c09dbe=1687406560',
            'Host': 'www.lizhi.fm',
            'Sec-Ch-Ua': '"Not.A/Brand";v="8", "Chromium";v="114", "Google Chrome";v="114"',
            'Sec-Ch-Ua-Mobile': '?0',
            'Sec-Ch-Ua-Platform': '"Windows"',
            'Sec-Fetch-Dest': 'document',
            'Sec-Fetch-Mode': 'navigate',
            'Sec-Fetch-Site': 'none',
            'Sec-Fetch-User': '?1',
            'Upgrade-Insecure-Requests': '1',
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36'
        }
        res = self.req.get(url=url, headers=headers)
        # 获取歌曲名称、出版时间、评论数
        tree = etree.HTML(res.text.strip())
        if tree is None:
            print('error------第{}页歌手歌曲详情页为None------'.format(self.page))
            return []
        songs_list = tree.xpath('//ul[@class="audioList fontYaHei js-audio-list"]')
        if len(songs_list) == 0:
            print(res.text.strip())
            return []
        songs_list = songs_list[0]
        # 解析歌曲信息
        song_codes = songs_list.xpath('./li/a/@href')
        song_codes = [x.split('/')[2] for x in song_codes]
        songs_name = songs_list.xpath('./li/a/div[1]/p[1]')
        # 有歌名为空
        songs_name = [item.xpath('./text()')[0] if len(item.xpath('./text()')) > 0 else '' for item in songs_name]
        publish_info = songs_list.xpath('./li/a/div[1]/p[2]/text()')
        publish_date = [x.split('\xa0\xa0\xa0')[0] for x in publish_info]
        comment_num = [x.split('\xa0\xa0\xa0')[1] for x in publish_info]
        # 校对不同标签的数据量
        if not (len(songs_name) == len(publish_date) == len(comment_num)):
            print('解析错误,数据项不吻合...:{},{},{}'.format(len(songs_name), len(publish_date), len(comment_num)))
            print(songs_name)
            print(publish_date)
            print(comment_num)
            return []
        # 只下载第一页的第一首歌
        if page > 1:
            songs = self.download_song(publish_date, song_codes, songs_name)
        else:
            songs = self.download_song(publish_date, song_codes, songs_name, not_download=False)
        songs_info = [{'song_name': songs_name[i], 'song':songs[i], 'publish_date': publish_date[i], 'comment_num': comment_num[i]} for i in range(len(songs_name))]
        return songs_info

    # 获取一页(24位)歌手的信息
    def get_one_page_singer_info(self, page):
        radio_list_info = self.parse_first_page(page=page)
        time.sleep(2 + 1 * random.random())
        total_songs = []
        radio_cnt = []
        signature = []
        for i, second_page_url in enumerate(radio_list_info['second_page_urls']):
            print('---------获取第{}页第{}位歌手的歌曲信息---------'.format(self.page, i))
            second_page = self.parse_second_page(second_page_url, i)
            total_songs.append(second_page['total_songs'])
            radio_cnt.append(second_page['radio_cnt'])
            signature.append(second_page['signature'])
            time.sleep(5 + 3 * random.random())
        radio_list_info.pop('second_page_urls')
        radio_list_info['radio_cnt'] = radio_cnt
        radio_list_info['signature'] = signature
        radio_list_info['total_songs'] = total_songs
        return radio_list_info

    def run(self):
        name = []
        image = []
        platform_code = []
        radio_cnt = []
        signature = []
        total_songs = []
        page = self.page
        print('-----------------获取第{}页的所有歌手信息-----------------'.format(page))
        one_page_singer_info = self.get_one_page_singer_info(page=page)
        name.extend(one_page_singer_info['name'])
        image.extend(one_page_singer_info['image'])
        platform_code.extend(one_page_singer_info['platform_code'])
        radio_cnt.extend(one_page_singer_info['radio_cnt'])
        signature.extend(one_page_singer_info['signature'])
        total_songs.extend(one_page_singer_info['total_songs'])
        time.sleep(10 + 5 * random.random())
        radio_list_info = {'page': page, 'name': name, 'image': image, 'platform_code': platform_code,
                           'radio_cnt': radio_cnt, 'signature': signature, 'total_songs': total_songs}
        self.result = radio_list_info
        print('-----------------获取第{}页的所有歌手信息完毕-----------------'.format(page))
        # self.write_to_excel(radio_list_info)


# 将数据保存至excel
def write_to_excel(radio_list_info):
    total_songs = radio_list_info['total_songs']
    radio_list_info['total_songs'] = ['=HYPERLINK("#child{}!A1", "click to browse detail")'.format(i+1) for i in range(len(total_songs))]
    radio_list_info['image'] = ['=HYPERLINK("{}", "{}")'.format(image_path, image_path) for image_path in radio_list_info['image']]
    # 创建主表
    df = pd.DataFrame(radio_list_info)
    # 创建 Excel writer
    writer = pd.ExcelWriter('LiZhiFM.xlsx')
    df.to_excel(writer, sheet_name='main', index=False)
    workbook = writer.book
    # 创建子表
    for i, df_child in enumerate(total_songs):
        sheet_name = 'child{}'.format(i+1)
        worksheet = workbook.add_worksheet(sheet_name)
        df_child.to_excel(writer, sheet_name=worksheet.name)
    # 关闭 Excel writer 并保存文件
    writer.close()


# 多线程爬取网页数据
def run():
    # 创建线程
    threads = []
    # 创建ip代理
    lg = LiuGuan()
    for i in range(1, 9):
        lz = LiZhiFM(page=i, lg=lg)
        threads.append(lz)
    # 开启线程
    for th in threads:
        th.start()
        time.sleep(5 + 3*random.random())
    # 阻塞线程
    for th in threads:
        th.join()
    # 获取结果并按页码排序
    results = [th.result for th in threads]
    results = sorted(results, key=lambda x: x['page'])
    # 重新组装数据
    name = []
    image = []
    platform_code = []
    radio_cnt = []
    signature = []
    total_songs = []
    for one_page_singer_info in results:
        name.extend(one_page_singer_info['name'])
        image.extend(one_page_singer_info['image'])
        platform_code.extend(one_page_singer_info['platform_code'])
        radio_cnt.extend(one_page_singer_info['radio_cnt'])
        signature.extend(one_page_singer_info['signature'])
        total_songs.extend(one_page_singer_info['total_songs'])
    radio_list_info = {'name': name, 'image': image, 'platform_code': platform_code,
                       'radio_cnt': radio_cnt, 'signature': signature, 'total_songs': total_songs}
    write_to_excel(radio_list_info)


if __name__ == "__main__":
    run()
